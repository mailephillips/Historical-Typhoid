
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Philadelphia.yr <- b.ltALL[,10]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Philadelphia.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Philadelphia.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Philadelphia        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,11]
allwatsupplyexp.Philadelphia           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,11]
allsewsysexp.Philadelphia              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,11]
allwatsupplyoutlays.Philadelphia       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,11]
allsewsysoutlays.Philadelphia          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,11]
allvalwatsuppsys.Philadelphia          <- read.csv("per capita financial data/watsuppval_percap.csv")[,11]
allfunddebtloanwatsuppsys.Philadelphia <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,11]
allfunddebtloansewsys.Philadelphia     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,11]


watsupprecpts.Philadelphia          <- lm(log(Philadelphia.lt.short)~allwatsupplyrecpts.Philadelphia)
watsupplyexp.Philadelphia           <- lm(log(Philadelphia.lt.short)~allwatsupplyexp.Philadelphia)
sewsysexp.Philadelphia              <- lm(log(Philadelphia.lt.short)~allsewsysexp.Philadelphia)
watsupplyoutlays.Philadelphia       <- lm(log(Philadelphia.lt.short)~allwatsupplyoutlays.Philadelphia)
sewsysoutlays.Philadelphia          <- lm(log(Philadelphia.lt.short)~allsewsysoutlays.Philadelphia)
valwatsuppsys.Philadelphia          <- lm(log(Philadelphia.lt.short)~allvalwatsuppsys.Philadelphia)
funddebtloanwatsuppsys.Philadelphia <- lm(log(Philadelphia.lt.short)~allfunddebtloanwatsuppsys.Philadelphia)
funddebtloansewsys.Philadelphia     <- lm(log(Philadelphia.lt.short)~allfunddebtloansewsys.Philadelphia)

summary(watsupprecpts.Philadelphia)
summary(watsupplyexp.Philadelphia) #not signif
summary(sewsysexp.Philadelphia)  #not signif
summary(watsupplyoutlays.Philadelphia)  #not signif
summary(sewsysoutlays.Philadelphia)
summary(valwatsuppsys.Philadelphia) #not signif
summary(funddebtloanwatsuppsys.Philadelphia)
summary(funddebtloansewsys.Philadelphia)

myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.Philadelphia <- rbind(myFun(watsupprecpts.Philadelphia), myFun(watsupplyexp.Philadelphia), 
                                  myFun(sewsysexp.Philadelphia), myFun(watsupplyoutlays.Philadelphia), 
                                  myFun(sewsysoutlays.Philadelphia), myFun(valwatsuppsys.Philadelphia), 
                                  myFun(funddebtloanwatsuppsys.Philadelphia), myFun(funddebtloansewsys.Philadelphia))
rownames(linear.results.Philadelphia) <- c("watsupprecpts.Philadelphia", "watsupplyexp.Philadelphia", "sewsysexp.Philadelphia", 
                                        "watsupplyoutlays.Philadelphia", "sewsysoutlays.Philadelphia", "valwatsuppsys.Philadelphia",
                                        "funddebtloanwatsuppsys.Philadelphia", "funddebtloansewsys.Philadelphia")
write.csv(linear.results.Philadelphia, "linear regression results Philadelphia.csv")
