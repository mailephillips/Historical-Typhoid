
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Pittsburgh.yr <- b.ltALL[,11]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Pittsburgh.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Pittsburgh.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Pittsburgh        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,12]
allwatsupplyexp.Pittsburgh           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,12]
allsewsysexp.Pittsburgh              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,12]
allwatsupplyoutlays.Pittsburgh       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,12]
allsewsysoutlays.Pittsburgh          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,12]
allvalwatsuppsys.Pittsburgh          <- read.csv("per capita financial data/watsuppval_percap.csv")[,12]
allfunddebtloanwatsuppsys.Pittsburgh <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,12]
allfunddebtloansewsys.Pittsburgh     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,12]


watsupprecpts.Pittsburgh          <- lm(log(Pittsburgh.lt.short)~allwatsupplyrecpts.Pittsburgh)
watsupplyexp.Pittsburgh           <- lm(log(Pittsburgh.lt.short)~allwatsupplyexp.Pittsburgh)
sewsysexp.Pittsburgh              <- lm(log(Pittsburgh.lt.short)~allsewsysexp.Pittsburgh)
watsupplyoutlays.Pittsburgh       <- lm(log(Pittsburgh.lt.short)~allwatsupplyoutlays.Pittsburgh)
sewsysoutlays.Pittsburgh          <- lm(log(Pittsburgh.lt.short)~allsewsysoutlays.Pittsburgh)
valwatsuppsys.Pittsburgh          <- lm(log(Pittsburgh.lt.short)~allvalwatsuppsys.Pittsburgh)
funddebtloanwatsuppsys.Pittsburgh <- lm(log(Pittsburgh.lt.short)~allfunddebtloanwatsuppsys.Pittsburgh)
funddebtloansewsys.Pittsburgh     <- lm(log(Pittsburgh.lt.short)~allfunddebtloansewsys.Pittsburgh)

summary(watsupprecpts.Pittsburgh)
summary(watsupplyexp.Pittsburgh)
summary(sewsysexp.Pittsburgh) #not signif
summary(watsupplyoutlays.Pittsburgh)
summary(sewsysoutlays.Pittsburgh) 
summary(valwatsuppsys.Pittsburgh)
summary(funddebtloanwatsuppsys.Pittsburgh)
summary(funddebtloansewsys.Pittsburgh)

myFun <- function(lm) {
    out <- c(lm$coefficients[1],
             lm$coefficients[2],
             summary(lm)$coefficients[2,2],
             summary(lm)$coefficients[2, (3:4)],
             summary(lm)$r.squared)
    names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
    return(out)}

linear.results.Pittsburgh <- rbind(myFun(watsupprecpts.Pittsburgh), myFun(watsupplyexp.Pittsburgh), 
      myFun(sewsysexp.Pittsburgh), myFun(watsupplyoutlays.Pittsburgh), 
      myFun(sewsysoutlays.Pittsburgh), myFun(valwatsuppsys.Pittsburgh), 
      myFun(funddebtloanwatsuppsys.Pittsburgh), myFun(funddebtloansewsys.Pittsburgh))
rownames(linear.results.Pittsburgh) <- c("watsupprecpts.Pittsburgh", "watsupplyexp.Pittsburgh", "sewsysexp.Pittsburgh", 
                                  "watsupplyoutlays.Pittsburgh", "sewsysoutlays.Pittsburgh", "valwatsuppsys.Pittsburgh",
                                  "funddebtloanwatsuppsys.Pittsburgh", "funddebtloansewsys.Pittsburgh")
write.csv(linear.results.Pittsburgh, "linear regression results Pittsburgh.csv")
