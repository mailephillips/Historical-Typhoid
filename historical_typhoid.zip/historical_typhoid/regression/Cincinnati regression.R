
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Cincinnati.yr <- b.ltALL[,4]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Cincinnati.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Cincinnati.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Cincinnati        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,5]
allwatsupplyexp.Cincinnati           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,5]
allsewsysexp.Cincinnati              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,5]
allwatsupplyoutlays.Cincinnati       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,5]
allsewsysoutlays.Cincinnati          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,5]
allvalwatsuppsys.Cincinnati          <- read.csv("per capita financial data/watsuppval_percap.csv")[,5]
allfunddebtloanwatsuppsys.Cincinnati <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,5]
allfunddebtloansewsys.Cincinnati     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,5]


watsupprecpts.Cincinnati          <- lm(log(Cincinnati.lt.short)~allwatsupplyrecpts.Cincinnati)
watsupplyexp.Cincinnati           <- lm(log(Cincinnati.lt.short)~allwatsupplyexp.Cincinnati)
sewsysexp.Cincinnati              <- lm(log(Cincinnati.lt.short)~allsewsysexp.Cincinnati)
watsupplyoutlays.Cincinnati       <- lm(log(Cincinnati.lt.short)~allwatsupplyoutlays.Cincinnati)
sewsysoutlays.Cincinnati          <- lm(log(Cincinnati.lt.short)~allsewsysoutlays.Cincinnati)
valwatsuppsys.Cincinnati          <- lm(log(Cincinnati.lt.short)~allvalwatsuppsys.Cincinnati)
funddebtloanwatsuppsys.Cincinnati <- lm(log(Cincinnati.lt.short)~allfunddebtloanwatsuppsys.Cincinnati)
funddebtloansewsys.Cincinnati     <- lm(log(Cincinnati.lt.short)~allfunddebtloansewsys.Cincinnati)

summary(watsupprecpts.Cincinnati)
summary(watsupplyexp.Cincinnati)
summary(sewsysexp.Cincinnati) #not signif
summary(watsupplyoutlays.Cincinnati) 
summary(sewsysoutlays.Cincinnati) #not signif
summary(valwatsuppsys.Cincinnati)
summary(funddebtloanwatsuppsys.Cincinnati)
summary(funddebtloansewsys.Cincinnati)


myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.Cincinnati <- rbind(myFun(watsupprecpts.Cincinnati), myFun(watsupplyexp.Cincinnati), 
                                  myFun(sewsysexp.Cincinnati), myFun(watsupplyoutlays.Cincinnati), 
                                  myFun(sewsysoutlays.Cincinnati), myFun(valwatsuppsys.Cincinnati), 
                                  myFun(funddebtloanwatsuppsys.Cincinnati), myFun(funddebtloansewsys.Cincinnati))
rownames(linear.results.Cincinnati) <- c("watsupprecpts.Cincinnati", "watsupplyexp.Cincinnati", "sewsysexp.Cincinnati", 
                                        "watsupplyoutlays.Cincinnati", "sewsysoutlays.Cincinnati", "valwatsuppsys.Cincinnati",
                                        "funddebtloanwatsuppsys.Cincinnati", "funddebtloansewsys.Cincinnati")
write.csv(linear.results.Cincinnati, "linear regression results Cincinnati.csv")