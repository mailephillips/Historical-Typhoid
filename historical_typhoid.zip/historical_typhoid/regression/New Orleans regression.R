
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.NewOrleans.yr <- b.ltALL[,8]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.NewOrleans.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
NewOrleans.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.NewOrleans        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,9]
allwatsupplyexp.NewOrleans           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,9]
allsewsysexp.NewOrleans              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,9]
allwatsupplyoutlays.NewOrleans       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,9]
allsewsysoutlays.NewOrleans          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,9]
allvalwatsuppsys.NewOrleans          <- read.csv("per capita financial data/watsuppval_percap.csv")[,9]
allfunddebtloanwatsuppsys.NewOrleans <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,9]
allfunddebtloansewsys.NewOrleans     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,9]


watsupprecpts.NewOrleans          <- lm(log(NewOrleans.lt.short)~allwatsupplyrecpts.NewOrleans)
watsupplyexp.NewOrleans           <- lm(log(NewOrleans.lt.short)~allwatsupplyexp.NewOrleans)
sewsysexp.NewOrleans              <- lm(log(NewOrleans.lt.short)~allsewsysexp.NewOrleans)
watsupplyoutlays.NewOrleans       <- lm(log(NewOrleans.lt.short)~allwatsupplyoutlays.NewOrleans)
sewsysoutlays.NewOrleans          <- lm(log(NewOrleans.lt.short)~allsewsysoutlays.NewOrleans)
valwatsuppsys.NewOrleans          <- lm(log(NewOrleans.lt.short)~allvalwatsuppsys.NewOrleans)
funddebtloanwatsuppsys.NewOrleans <- lm(log(NewOrleans.lt.short)~allfunddebtloanwatsuppsys.NewOrleans)
funddebtloansewsys.NewOrleans     <- lm(log(NewOrleans.lt.short)~allfunddebtloansewsys.NewOrleans)

summary(watsupprecpts.NewOrleans)
summary(watsupplyexp.NewOrleans)
summary(sewsysexp.NewOrleans) 
summary(watsupplyoutlays.NewOrleans)#not signif
summary(sewsysoutlays.NewOrleans) #not signif
summary(valwatsuppsys.NewOrleans)
summary(funddebtloanwatsuppsys.NewOrleans)
summary(funddebtloansewsys.NewOrleans) #marg 

myFun <- function(lm) {
    out <- c(lm$coefficients[1],
             lm$coefficients[2],
             summary(lm)$coefficients[2,2],
             summary(lm)$coefficients[2, (3:4)],
             summary(lm)$r.squared)
    names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
    return(out)}

linear.results.NewOrleans <- rbind(myFun(watsupprecpts.NewOrleans), myFun(watsupplyexp.NewOrleans), 
      myFun(sewsysexp.NewOrleans), myFun(watsupplyoutlays.NewOrleans), 
      myFun(sewsysoutlays.NewOrleans), myFun(valwatsuppsys.NewOrleans), 
      myFun(funddebtloanwatsuppsys.NewOrleans), myFun(funddebtloansewsys.NewOrleans))
rownames(linear.results.NewOrleans) <- c("watsupprecpts.NewOrleans", "watsupplyexp.NewOrleans", "sewsysexp.NewOrleans", 
                                  "watsupplyoutlays.NewOrleans", "sewsysoutlays.NewOrleans", "valwatsuppsys.NewOrleans",
                                  "funddebtloanwatsuppsys.NewOrleans", "funddebtloansewsys.NewOrleans")
write.csv(linear.results.NewOrleans, "linear regression results New Orleans.csv")
