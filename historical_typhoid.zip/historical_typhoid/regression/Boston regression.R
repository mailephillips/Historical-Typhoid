rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Boston.yr <- b.ltALL[,2]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Boston.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Boston.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Boston        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,3]
allwatsupplyexp.Boston           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,3]
allsewsysexp.Boston              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,3]
allwatsupplyoutlays.Boston       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,3]
allsewsysoutlays.Boston          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,3]
allvalwatsuppsys.Boston          <- read.csv("per capita financial data/watsuppval_percap.csv")[,3]
allfunddebtloanwatsuppsys.Boston <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,3]
allfunddebtloansewsys.Boston     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,3]


watsupprecpts.Boston          <- lm(log(Boston.lt.short)~allwatsupplyrecpts.Boston)
watsupplyexp.Boston           <- lm(log(Boston.lt.short)~allwatsupplyexp.Boston)
sewsysexp.Boston              <- lm(log(Boston.lt.short)~allsewsysexp.Boston)
watsupplyoutlays.Boston       <- lm(log(Boston.lt.short)~allwatsupplyoutlays.Boston)
sewsysoutlays.Boston          <- lm(log(Boston.lt.short)~allsewsysoutlays.Boston)
valwatsuppsys.Boston          <- lm(log(Boston.lt.short)~allvalwatsuppsys.Boston)
funddebtloanwatsuppsys.Boston <- lm(log(Boston.lt.short)~allfunddebtloanwatsuppsys.Boston)
funddebtloansewsys.Boston     <- lm(log(Boston.lt.short)~allfunddebtloansewsys.Boston)

summary(watsupprecpts.Boston)
summary(watsupplyexp.Boston)
summary(sewsysexp.Boston) #not signif
summary(watsupplyoutlays.Boston) #not signif
summary(sewsysoutlays.Boston) #not signif
summary(valwatsuppsys.Boston)
summary(funddebtloanwatsuppsys.Boston)
summary(funddebtloansewsys.Boston)


myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.Boston <- rbind(myFun(watsupprecpts.Boston), myFun(watsupplyexp.Boston), 
                                  myFun(sewsysexp.Boston), myFun(watsupplyoutlays.Boston), 
                                  myFun(sewsysoutlays.Boston), myFun(valwatsuppsys.Boston), 
                                  myFun(funddebtloanwatsuppsys.Boston), myFun(funddebtloansewsys.Boston))
rownames(linear.results.Boston) <- c("watsupprecpts.Boston", "watsupplyexp.Boston", "sewsysexp.Boston", 
                                        "watsupplyoutlays.Boston", "sewsysoutlays.Boston", "valwatsuppsys.Boston",
                                        "funddebtloanwatsuppsys.Boston", "funddebtloansewsys.Boston")
write.csv(linear.results.Boston, "linear regression results Boston.csv")