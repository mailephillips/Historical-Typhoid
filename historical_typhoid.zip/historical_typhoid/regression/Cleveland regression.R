

rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Cleveland.yr <- b.ltALL[,5]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Cleveland.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Cleveland.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Cleveland        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,6]
allwatsupplyexp.Cleveland           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,6]
allsewsysexp.Cleveland              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,6]
allwatsupplyoutlays.Cleveland       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,6]
allsewsysoutlays.Cleveland          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,6]
allvalwatsuppsys.Cleveland          <- read.csv("per capita financial data/watsuppval_percap.csv")[,6]
allfunddebtloanwatsuppsys.Cleveland <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,6]
allfunddebtloansewsys.Cleveland     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,6]


watsupprecpts.Cleveland          <- lm(log(Cleveland.lt.short)~allwatsupplyrecpts.Cleveland)
watsupplyexp.Cleveland           <- lm(log(Cleveland.lt.short)~allwatsupplyexp.Cleveland)
sewsysexp.Cleveland              <- lm(log(Cleveland.lt.short)~allsewsysexp.Cleveland)
watsupplyoutlays.Cleveland       <- lm(log(Cleveland.lt.short)~allwatsupplyoutlays.Cleveland)
sewsysoutlays.Cleveland          <- lm(log(Cleveland.lt.short)~allsewsysoutlays.Cleveland)
valwatsuppsys.Cleveland          <- lm(log(Cleveland.lt.short)~allvalwatsuppsys.Cleveland)
funddebtloanwatsuppsys.Cleveland <- lm(log(Cleveland.lt.short)~allfunddebtloanwatsuppsys.Cleveland)
funddebtloansewsys.Cleveland     <- lm(log(Cleveland.lt.short)~allfunddebtloansewsys.Cleveland)

summary(watsupprecpts.Cleveland)
summary(watsupplyexp.Cleveland)
summary(sewsysexp.Cleveland) #not signif
summary(watsupplyoutlays.Cleveland) #not signif
summary(sewsysoutlays.Cleveland)
summary(valwatsuppsys.Cleveland)
summary(funddebtloanwatsuppsys.Cleveland)
summary(funddebtloansewsys.Cleveland) #not signif


myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.Cleveland <- rbind(myFun(watsupprecpts.Cleveland), myFun(watsupplyexp.Cleveland), 
                                  myFun(sewsysexp.Cleveland), myFun(watsupplyoutlays.Cleveland), 
                                  myFun(sewsysoutlays.Cleveland), myFun(valwatsuppsys.Cleveland), 
                                  myFun(funddebtloanwatsuppsys.Cleveland), myFun(funddebtloansewsys.Cleveland))
rownames(linear.results.Cleveland) <- c("watsupprecpts.Cleveland", "watsupplyexp.Cleveland", "sewsysexp.Cleveland", 
                                        "watsupplyoutlays.Cleveland", "sewsysoutlays.Cleveland", "valwatsuppsys.Cleveland",
                                        "funddebtloanwatsuppsys.Cleveland", "funddebtloansewsys.Cleveland")
write.csv(linear.results.Cleveland, "linear regression results Cleveland.csv")
