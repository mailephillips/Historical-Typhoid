
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

#Convert to yearly average
b.lt.Baltimore.yr <- b.ltALL[,1]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Baltimore.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Baltimore.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Baltimore        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,2]
allwatsupplyexp.Baltimore           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,2]
allsewsysexp.Baltimore              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,2]
allwatsupplyoutlays.Baltimore       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,2]
allsewsysoutlays.Baltimore          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,2]
allvalwatsuppsys.Baltimore          <- read.csv("per capita financial data/watsuppval_percap.csv")[,2]
allfunddebtloanwatsuppsys.Baltimore <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,2]
allfunddebtloansewsys.Baltimore     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,2]

watsupprecpts.Baltimore          <- lm(log(Baltimore.lt.short)~allwatsupplyrecpts.Baltimore)
watsupplyexp.Baltimore           <- lm(log(Baltimore.lt.short)~allwatsupplyexp.Baltimore)
sewsysexp.Baltimore              <- lm(log(Baltimore.lt.short)~allsewsysexp.Baltimore)
watsupplyoutlays.Baltimore       <- lm(log(Baltimore.lt.short)~allwatsupplyoutlays.Baltimore)
sewsysoutlays.Baltimore          <- lm(log(Baltimore.lt.short)~allsewsysoutlays.Baltimore)
valwatsuppsys.Baltimore          <- lm(log(Baltimore.lt.short)~allvalwatsuppsys.Baltimore)
funddebtloanwatsuppsys.Baltimore <- lm(log(Baltimore.lt.short)~allfunddebtloanwatsuppsys.Baltimore)
funddebtloansewsys.Baltimore     <- lm(log(Baltimore.lt.short)~allfunddebtloansewsys.Baltimore)

summary(watsupprecpts.Baltimore)
summary(watsupplyexp.Baltimore)
summary(sewsysexp.Baltimore) #not signif
summary(watsupplyoutlays.Baltimore) 
summary(sewsysoutlays.Baltimore) #not signif
summary(valwatsuppsys.Baltimore)
summary(funddebtloanwatsuppsys.Baltimore)
summary(funddebtloansewsys.Baltimore)

myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.Baltimore <- rbind(myFun(watsupprecpts.Baltimore), myFun(watsupplyexp.Baltimore), 
                            myFun(sewsysexp.Baltimore), myFun(watsupplyoutlays.Baltimore), 
                            myFun(sewsysoutlays.Baltimore), myFun(valwatsuppsys.Baltimore), 
                            myFun(funddebtloanwatsuppsys.Baltimore), myFun(funddebtloansewsys.Baltimore))
rownames(linear.results.Baltimore) <- c("watsupprecpts.Baltimore", "watsupplyexp.Baltimore", "sewsysexp.Baltimore", 
                                  "watsupplyoutlays.Baltimore", "sewsysoutlays.Baltimore", "valwatsuppsys.Baltimore",
                                  "funddebtloanwatsuppsys.Baltimore", "funddebtloansewsys.Baltimore")
write.csv(linear.results.Baltimore, "linear regression results Baltimore.csv")
