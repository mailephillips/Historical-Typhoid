
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.WashDC.yr <- b.ltALL[,16]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.WashDC.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
WashDC.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.WashDC        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,17]
allwatsupplyexp.WashDC           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,17]
allsewsysexp.WashDC              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,17]
allwatsupplyoutlays.WashDC       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,17]
allsewsysoutlays.WashDC          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,17]
allvalwatsuppsys.WashDC          <- read.csv("per capita financial data/watsuppval_percap.csv")[,17]
allfunddebtloanwatsuppsys.WashDC <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,17]
allfunddebtloansewsys.WashDC     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,17]


watsupprecpts.WashDC          <- lm(log(WashDC.lt.short)~allwatsupplyrecpts.WashDC)
watsupplyexp.WashDC           <- lm(log(WashDC.lt.short)~allwatsupplyexp.WashDC)
sewsysexp.WashDC              <- lm(log(WashDC.lt.short)~allsewsysexp.WashDC)
watsupplyoutlays.WashDC       <- lm(log(WashDC.lt.short)~allwatsupplyoutlays.WashDC)
sewsysoutlays.WashDC          <- lm(log(WashDC.lt.short)~allsewsysoutlays.WashDC)
valwatsuppsys.WashDC          <- lm(log(WashDC.lt.short)~allvalwatsuppsys.WashDC)
# funddebtloanwatsuppsys.WashDC <- lm(WashDC.lt.short~allfunddebtloanwatsuppsys.WashDC)
# funddebtloansewsys.WashDC     <- lm(WashDC.lt.short~allfunddebtloansewsys.WashDC)

summary(watsupprecpts.WashDC)
summary(watsupplyexp.WashDC)
summary(sewsysexp.WashDC) #not signif
summary(watsupplyoutlays.WashDC) #not signif
summary(sewsysoutlays.WashDC) #not signif
summary(valwatsuppsys.WashDC) #not signif
# summary(funddebtloanwatsuppsys.WashDC)
# summary(funddebtloansewsys.WashDC)

myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.WashDC <- rbind(myFun(watsupprecpts.WashDC), myFun(watsupplyexp.WashDC), 
                                  myFun(sewsysexp.WashDC), myFun(watsupplyoutlays.WashDC), 
                                  myFun(sewsysoutlays.WashDC), myFun(valwatsuppsys.WashDC))
rownames(linear.results.WashDC) <- c("watsupprecpts.WashDC", "watsupplyexp.WashDC", "sewsysexp.WashDC", 
                                        "watsupplyoutlays.WashDC", "sewsysoutlays.WashDC", "valwatsuppsys.WashDC")
write.csv(linear.results.WashDC, "linear regression results Washington DC 2.csv")
