

rm(list=ls(all=TRUE))
setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.SanFrancisco.yr <- b.ltALL[,14]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.SanFrancisco.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
SanFrancisco.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.SanFrancisco        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,15]
allwatsupplyexp.SanFrancisco           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,15]
allsewsysexp.SanFrancisco              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,15]
allwatsupplyoutlays.SanFrancisco       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,15]
allsewsysoutlays.SanFrancisco          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,15]
allvalwatsuppsys.SanFrancisco          <- read.csv("per capita financial data/watsuppval_percap.csv")[,15]
allfunddebtloanwatsuppsys.SanFrancisco <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,15]
allfunddebtloansewsys.SanFrancisco     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,15]


watsupprecpts.SanFrancisco          <- lm(log(SanFrancisco.lt.short)~allwatsupplyrecpts.SanFrancisco)
watsupplyexp.SanFrancisco           <- lm(log(SanFrancisco.lt.short)~allwatsupplyexp.SanFrancisco)
sewsysexp.SanFrancisco              <- lm(log(SanFrancisco.lt.short)~allsewsysexp.SanFrancisco)
watsupplyoutlays.SanFrancisco       <- lm(log(SanFrancisco.lt.short)~allwatsupplyoutlays.SanFrancisco)
sewsysoutlays.SanFrancisco          <- lm(log(SanFrancisco.lt.short)~allsewsysoutlays.SanFrancisco)
valwatsuppsys.SanFrancisco          <- lm(log(SanFrancisco.lt.short)~allvalwatsuppsys.SanFrancisco)
funddebtloanwatsuppsys.SanFrancisco <- lm(log(SanFrancisco.lt.short)~allfunddebtloanwatsuppsys.SanFrancisco)
funddebtloansewsys.SanFrancisco     <- lm(log(SanFrancisco.lt.short)~allfunddebtloansewsys.SanFrancisco)

summary(watsupprecpts.SanFrancisco) #not signif
summary(watsupplyexp.SanFrancisco)#not signif
summary(sewsysexp.SanFrancisco) #not signif
summary(watsupplyoutlays.SanFrancisco) #marg
summary(sewsysoutlays.SanFrancisco) #not signif
summary(valwatsuppsys.SanFrancisco)
summary(funddebtloanwatsuppsys.SanFrancisco) 
summary(funddebtloansewsys.SanFrancisco) 

myFun <- function(lm) {
    out <- c(lm$coefficients[1],
             lm$coefficients[2],
             summary(lm)$coefficients[2,2],
             summary(lm)$coefficients[2, (3:4)],
             summary(lm)$r.squared)
    names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
    return(out)}

linear.results.SanFrancisco <- rbind(myFun(watsupprecpts.SanFrancisco), myFun(watsupplyexp.SanFrancisco), 
      myFun(sewsysexp.SanFrancisco), myFun(watsupplyoutlays.SanFrancisco), 
      myFun(sewsysoutlays.SanFrancisco), myFun(valwatsuppsys.SanFrancisco), 
      myFun(funddebtloanwatsuppsys.SanFrancisco), myFun(funddebtloansewsys.SanFrancisco))
rownames(linear.results.SanFrancisco) <- c("watsupprecpts.SanFrancisco", "watsupplyexp.SanFrancisco", "sewsysexp.SanFrancisco", 
                                  "watsupplyoutlays.SanFrancisco", "sewsysoutlays.SanFrancisco", "valwatsuppsys.SanFrancisco",
                                  "funddebtloanwatsuppsys.SanFrancisco", "funddebtloansewsys.SanFrancisco")
write.csv(linear.results.SanFrancisco, "linear regression results San Francisco.csv")
