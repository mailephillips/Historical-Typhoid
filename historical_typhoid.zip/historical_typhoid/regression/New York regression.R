
rm(list=ls(all=TRUE))
setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.ny.yr <- b.ltALL[,9]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.ny.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
ny.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.ny        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,10]
allwatsupplyexp.ny           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,10]
allsewsysexp.ny              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,10]
allwatsupplyoutlays.ny       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,10]
allsewsysoutlays.ny          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,10]
allvalwatsuppsys.ny          <- read.csv("per capita financial data/watsuppval_percap.csv")[,10]
allfunddebtloanwatsuppsys.ny <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,10]
allfunddebtloansewsys.ny     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,10]


watsupprecpts.nyc          <- lm(log(ny.lt.short)~allwatsupplyrecpts.ny)
watsupplyexp.nyc           <- lm(log(ny.lt.short)~allwatsupplyexp.ny)
sewsysexp.nyc              <- lm(log(ny.lt.short)~allsewsysexp.ny)
watsupplyoutlays.nyc       <- lm(log(ny.lt.short)~allwatsupplyoutlays.ny)
sewsysoutlays.nyc          <- lm(log(ny.lt.short)~allsewsysoutlays.ny)
valwatsuppsys.nyc          <- lm(log(ny.lt.short)~allvalwatsuppsys.ny)
funddebtloanwatsuppsys.nyc <- lm(log(ny.lt.short)~allfunddebtloanwatsuppsys.ny)
funddebtloansewsys.nyc     <- lm(log(ny.lt.short)~allfunddebtloansewsys.ny)

summary(watsupprecpts.nyc)
summary(watsupplyexp.nyc)
summary(sewsysexp.nyc) #not signif
summary(watsupplyoutlays.nyc) #not signif
summary(sewsysoutlays.nyc)
summary(valwatsuppsys.nyc)
summary(funddebtloanwatsuppsys.nyc)
summary(funddebtloansewsys.nyc) #not signif

myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.nyc <- rbind(myFun(watsupprecpts.nyc), myFun(watsupplyexp.nyc), 
                                myFun(sewsysexp.nyc), myFun(watsupplyoutlays.nyc), 
                                myFun(sewsysoutlays.nyc), myFun(valwatsuppsys.nyc), 
                                myFun(funddebtloanwatsuppsys.nyc), myFun(funddebtloansewsys.nyc))
rownames(linear.results.nyc) <- c("watsupprecpts.nyc", "watsupplyexp.nyc", "sewsysexp.nyc", 
                                      "watsupplyoutlays.nyc", "sewsysoutlays.nyc", "valwatsuppsys.nyc",
                                      "funddebtloanwatsuppsys.nyc", "funddebtloansewsys.nyc")
write.csv(linear.results.nyc, "linear regression results New York.csv")
