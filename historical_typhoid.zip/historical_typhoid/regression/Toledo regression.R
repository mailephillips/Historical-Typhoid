
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Toledo.yr <- b.ltALL[,15]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Toledo.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Toledo.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Toledo        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,16]
allwatsupplyexp.Toledo           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,16]
allsewsysexp.Toledo              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,16]
allwatsupplyoutlays.Toledo       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,16]
allsewsysoutlays.Toledo          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,16]
allvalwatsuppsys.Toledo          <- read.csv("per capita financial data/watsuppval_percap.csv")[,16]
allfunddebtloanwatsuppsys.Toledo <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,16]
allfunddebtloansewsys.Toledo     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,16]


watsupprecpts.Toledo          <- lm(log(Toledo.lt.short)~allwatsupplyrecpts.Toledo)
watsupplyexp.Toledo           <- lm(log(Toledo.lt.short)~allwatsupplyexp.Toledo)
sewsysexp.Toledo              <- lm(log(Toledo.lt.short)~allsewsysexp.Toledo)
watsupplyoutlays.Toledo       <- lm(log(Toledo.lt.short)~allwatsupplyoutlays.Toledo)
sewsysoutlays.Toledo          <- lm(log(Toledo.lt.short)~allsewsysoutlays.Toledo)
valwatsuppsys.Toledo          <- lm(log(Toledo.lt.short)~allvalwatsuppsys.Toledo)
funddebtloanwatsuppsys.Toledo <- lm(log(Toledo.lt.short)~allfunddebtloanwatsuppsys.Toledo)
funddebtloansewsys.Toledo     <- lm(log(Toledo.lt.short)~allfunddebtloansewsys.Toledo)

summary(watsupprecpts.Toledo)
summary(watsupplyexp.Toledo)
summary(sewsysexp.Toledo) #not signif
summary(watsupplyoutlays.Toledo) #not signif
summary(sewsysoutlays.Toledo)
summary(valwatsuppsys.Toledo)
summary(funddebtloanwatsuppsys.Toledo) #not signif
summary(funddebtloansewsys.Toledo)

myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.Toledo <- rbind(myFun(watsupprecpts.Toledo), myFun(watsupplyexp.Toledo), 
                                  myFun(sewsysexp.Toledo), myFun(watsupplyoutlays.Toledo), 
                                  myFun(sewsysoutlays.Toledo), myFun(valwatsuppsys.Toledo), 
                                  myFun(funddebtloanwatsuppsys.Toledo), myFun(funddebtloansewsys.Toledo))
rownames(linear.results.Toledo) <- c("watsupprecpts.Toledo", "watsupplyexp.Toledo", "sewsysexp.Toledo", 
                                        "watsupplyoutlays.Toledo", "sewsysoutlays.Toledo", "valwatsuppsys.Toledo",
                                        "funddebtloanwatsuppsys.Toledo", "funddebtloansewsys.Toledo")
write.csv(linear.results.Toledo, "linear regression results Toledo.csv")
