detach(df)
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Chicago.yr <- b.ltALL[,3]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Chicago.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Chicago.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Chicago        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,4]
allwatsupplyexp.Chicago           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,4]
allsewsysexp.Chicago              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,4]
allwatsupplyoutlays.Chicago       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,4]
allsewsysoutlays.Chicago          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,4]
allvalwatsuppsys.Chicago          <- read.csv("per capita financial data/watsuppval_percap.csv")[,4]
allfunddebtloanwatsuppsys.Chicago <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,4]
allfunddebtloansewsys.Chicago     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,4]


watsupprecpts.Chicago          <- lm(log(Chicago.lt.short)~allwatsupplyrecpts.Chicago)
watsupplyexp.Chicago           <- lm(log(Chicago.lt.short)~allwatsupplyexp.Chicago)
sewsysexp.Chicago              <- lm(log(Chicago.lt.short)~allsewsysexp.Chicago)
watsupplyoutlays.Chicago       <- lm(log(Chicago.lt.short)~allwatsupplyoutlays.Chicago)
sewsysoutlays.Chicago          <- lm(log(Chicago.lt.short)~allsewsysoutlays.Chicago)
valwatsuppsys.Chicago          <- lm(log(Chicago.lt.short)~allvalwatsuppsys.Chicago)
funddebtloanwatsuppsys.Chicago <- lm(log(Chicago.lt.short)~allfunddebtloanwatsuppsys.Chicago)
funddebtloansewsys.Chicago     <- lm(log(Chicago.lt.short)~allfunddebtloansewsys.Chicago)

summary(watsupprecpts.Chicago)
summary(watsupplyexp.Chicago)
confint(watsupplyexp.Chicago)
exp(confint(watsupplyexp.Chicago)[2,])
summary(sewsysexp.Chicago)
summary(watsupplyoutlays.Chicago) 
summary(sewsysoutlays.Chicago) 
summary(valwatsuppsys.Chicago)
summary(funddebtloanwatsuppsys.Chicago) 
summary(funddebtloansewsys.Chicago)


myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.Chicago <- rbind(myFun(watsupprecpts.Chicago), myFun(watsupplyexp.Chicago), 
                                  myFun(sewsysexp.Chicago), myFun(watsupplyoutlays.Chicago), 
                                  myFun(sewsysoutlays.Chicago), myFun(valwatsuppsys.Chicago), 
                                  myFun(funddebtloanwatsuppsys.Chicago), myFun(funddebtloansewsys.Chicago))
rownames(linear.results.Chicago) <- c("watsupprecpts.Chicago", "watsupplyexp.Chicago", "sewsysexp.Chicago", 
                                        "watsupplyoutlays.Chicago", "sewsysoutlays.Chicago", "valwatsuppsys.Chicago",
                                        "funddebtloanwatsuppsys.Chicago", "funddebtloansewsys.Chicago")
write.csv(linear.results.Chicago, "linear regression results Chicago.csv")
