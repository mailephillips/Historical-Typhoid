
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.StLouis.yr <- b.ltALL[,13]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.StLouis.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
StLouis.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.StLouis        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,14]
allwatsupplyexp.StLouis           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,14]
allsewsysexp.StLouis              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,14]
allwatsupplyoutlays.StLouis       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,14]
allsewsysoutlays.StLouis          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,14]
allvalwatsuppsys.StLouis          <- read.csv("per capita financial data/watsuppval_percap.csv")[,14]
allfunddebtloanwatsuppsys.StLouis <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,14]
allfunddebtloansewsys.StLouis     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,14]


watsupprecpts.StLouis          <- lm(log(StLouis.lt.short)~allwatsupplyrecpts.StLouis)
watsupplyexp.StLouis           <- lm(log(StLouis.lt.short)~allwatsupplyexp.StLouis)
sewsysexp.StLouis              <- lm(log(StLouis.lt.short)~allsewsysexp.StLouis)
watsupplyoutlays.StLouis       <- lm(log(StLouis.lt.short)~allwatsupplyoutlays.StLouis)
sewsysoutlays.StLouis          <- lm(log(StLouis.lt.short)~allsewsysoutlays.StLouis)
valwatsuppsys.StLouis          <- lm(log(StLouis.lt.short)~allvalwatsuppsys.StLouis)
funddebtloanwatsuppsys.StLouis <- lm(log(StLouis.lt.short)~allfunddebtloanwatsuppsys.StLouis)
funddebtloansewsys.StLouis     <- lm(log(StLouis.lt.short)~allfunddebtloansewsys.StLouis)

summary(watsupprecpts.StLouis) 
summary(watsupplyexp.StLouis)
summary(sewsysexp.StLouis) #not signif
summary(watsupplyoutlays.StLouis) #not signif
summary(sewsysoutlays.StLouis) 
summary(valwatsuppsys.StLouis) #not signif
summary(funddebtloanwatsuppsys.StLouis) 
summary(funddebtloansewsys.StLouis) 

myFun <- function(lm) {
    out <- c(lm$coefficients[1],
             lm$coefficients[2],
             summary(lm)$coefficients[2,2],
             summary(lm)$coefficients[2, (3:4)],
             summary(lm)$r.squared)
    names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
    return(out)}

linear.results.StLouis <- rbind(myFun(watsupprecpts.StLouis), myFun(watsupplyexp.StLouis), 
      myFun(sewsysexp.StLouis), myFun(watsupplyoutlays.StLouis), 
      myFun(sewsysoutlays.StLouis), myFun(valwatsuppsys.StLouis), 
      myFun(funddebtloanwatsuppsys.StLouis), myFun(funddebtloansewsys.StLouis))
rownames(linear.results.StLouis) <- c("watsupprecpts.StLouis", "watsupplyexp.StLouis", "sewsysexp.StLouis", 
                                  "watsupplyoutlays.StLouis", "sewsysoutlays.StLouis", "valwatsuppsys.StLouis",
                                  "funddebtloanwatsuppsys.StLouis", "funddebtloansewsys.StLouis")
write.csv(linear.results.StLouis, "linear regression results St. Louis.csv")