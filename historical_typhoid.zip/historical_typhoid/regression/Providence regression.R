
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Providence.yr <- b.ltALL[,12]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Providence.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Providence.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Providence        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,13]
allwatsupplyexp.Providence           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,13]
allsewsysexp.Providence              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,13]
allwatsupplyoutlays.Providence       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,13]
allsewsysoutlays.Providence          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,13]
allvalwatsuppsys.Providence          <- read.csv("per capita financial data/watsuppval_percap.csv")[,13]
allfunddebtloanwatsuppsys.Providence <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,13]
allfunddebtloansewsys.Providence     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,13]

watsupprecpts.Providence          <- lm(log(Providence.lt.short)~allwatsupplyrecpts.Providence)
watsupplyexp.Providence           <- lm(log(Providence.lt.short)~allwatsupplyexp.Providence)
sewsysexp.Providence              <- lm(log(Providence.lt.short)~allsewsysexp.Providence)
watsupplyoutlays.Providence       <- lm(log(Providence.lt.short)~allwatsupplyoutlays.Providence)
sewsysoutlays.Providence          <- lm(log(Providence.lt.short)~allsewsysoutlays.Providence)
valwatsuppsys.Providence          <- lm(log(Providence.lt.short)~allvalwatsuppsys.Providence)
funddebtloanwatsuppsys.Providence <- lm(log(Providence.lt.short)~allfunddebtloanwatsuppsys.Providence)
funddebtloansewsys.Providence     <- lm(log(Providence.lt.short)~allfunddebtloansewsys.Providence)

summary(watsupprecpts.Providence)
summary(watsupplyexp.Providence)
summary(sewsysexp.Providence) 
summary(watsupplyoutlays.Providence)
summary(sewsysoutlays.Providence) 
summary(valwatsuppsys.Providence)
summary(funddebtloanwatsuppsys.Providence) 
summary(funddebtloansewsys.Providence) #not signif

myFun <- function(lm) {
    out <- c(lm$coefficients[1],
             lm$coefficients[2],
             summary(lm)$coefficients[2,2],
             summary(lm)$coefficients[2, (3:4)],
             summary(lm)$r.squared)
    names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
    return(out)}

linear.results.Providence <- rbind(myFun(watsupprecpts.Providence), myFun(watsupplyexp.Providence), 
      myFun(sewsysexp.Providence), myFun(watsupplyoutlays.Providence), 
      myFun(sewsysoutlays.Providence), myFun(valwatsuppsys.Providence), 
      myFun(funddebtloanwatsuppsys.Providence), myFun(funddebtloansewsys.Providence))
rownames(linear.results.Providence) <- c("watsupprecpts.Providence", "watsupplyexp.Providence", "sewsysexp.Providence", 
                                  "watsupplyoutlays.Providence", "sewsysoutlays.Providence", "valwatsuppsys.Providence",
                                  "funddebtloanwatsuppsys.Providence", "funddebtloansewsys.Providence")
write.csv(linear.results.Providence, "linear regression results Providence.csv")
