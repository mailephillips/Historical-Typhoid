
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Milwaukee.yr <- b.ltALL[,6]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Milwaukee.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Milwaukee.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Milwaukee        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,7]
allwatsupplyexp.Milwaukee           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,7]
allsewsysexp.Milwaukee              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,7]
allwatsupplyoutlays.Milwaukee       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,7]
allsewsysoutlays.Milwaukee          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,7]
allvalwatsuppsys.Milwaukee          <- read.csv("per capita financial data/watsuppval_percap.csv")[,7]
allfunddebtloanwatsuppsys.Milwaukee <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,7]
allfunddebtloansewsys.Milwaukee     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,7]


watsupprecpts.Milwaukee          <- lm(log(Milwaukee.lt.short)~allwatsupplyrecpts.Milwaukee)
watsupplyexp.Milwaukee           <- lm(log(Milwaukee.lt.short)~allwatsupplyexp.Milwaukee)
sewsysexp.Milwaukee              <- lm(log(Milwaukee.lt.short)~allsewsysexp.Milwaukee)
watsupplyoutlays.Milwaukee       <- lm(log(Milwaukee.lt.short)~allwatsupplyoutlays.Milwaukee)
sewsysoutlays.Milwaukee          <- lm(log(Milwaukee.lt.short)~allsewsysoutlays.Milwaukee)
valwatsuppsys.Milwaukee          <- lm(log(Milwaukee.lt.short)~allvalwatsuppsys.Milwaukee)
funddebtloanwatsuppsys.Milwaukee <- lm(log(Milwaukee.lt.short)~allfunddebtloanwatsuppsys.Milwaukee)
funddebtloansewsys.Milwaukee     <- lm(log(Milwaukee.lt.short)~allfunddebtloansewsys.Milwaukee)

summary(watsupprecpts.Milwaukee)
summary(watsupplyexp.Milwaukee)
summary(sewsysexp.Milwaukee)
summary(watsupplyoutlays.Milwaukee) 
summary(sewsysoutlays.Milwaukee)
summary(valwatsuppsys.Milwaukee)
summary(funddebtloanwatsuppsys.Milwaukee) #not signif
summary(funddebtloansewsys.Milwaukee)

myFun <- function(lm) {
  out <- c(lm$coefficients[1],
           lm$coefficients[2],
           summary(lm)$coefficients[2,2],
           summary(lm)$coefficients[2, (3:4)],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
  return(out)}

linear.results.Milwaukee <- rbind(myFun(watsupprecpts.Milwaukee), myFun(watsupplyexp.Milwaukee), 
                                  myFun(sewsysexp.Milwaukee), myFun(watsupplyoutlays.Milwaukee), 
                                  myFun(sewsysoutlays.Milwaukee), myFun(valwatsuppsys.Milwaukee), 
                                  myFun(funddebtloanwatsuppsys.Milwaukee), myFun(funddebtloansewsys.Milwaukee))
rownames(linear.results.Milwaukee) <- c("watsupprecpts.Milwaukee", "watsupplyexp.Milwaukee", "sewsysexp.Milwaukee", 
                                        "watsupplyoutlays.Milwaukee", "sewsysoutlays.Milwaukee", "valwatsuppsys.Milwaukee",
                                        "funddebtloanwatsuppsys.Milwaukee", "funddebtloansewsys.Milwaukee")
write.csv(linear.results.Milwaukee, "linear regression results Milwaukee.csv")
