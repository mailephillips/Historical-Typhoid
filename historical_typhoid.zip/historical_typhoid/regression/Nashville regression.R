

rm(list=ls(all=TRUE))
setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.Nashville.yr <- b.ltALL[,7]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.Nashville.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
Nashville.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

allwatsupplyrecpts.Nashville        <- read.csv("per capita financial data/watsuppreceipts_percap.csv")[,8]
allwatsupplyexp.Nashville           <- read.csv("per capita financial data/watsuppexpenses_percap.csv")[,8]
allsewsysexp.Nashville              <- read.csv("per capita financial data/sewsysexpenses_percap.csv")[,8]
allwatsupplyoutlays.Nashville       <- read.csv("per capita financial data/watsuppoutlays_percap.csv")[,8]
allsewsysoutlays.Nashville          <- read.csv("per capita financial data/sewsysoutlays_percap.csv")[,8]
allvalwatsuppsys.Nashville          <- read.csv("per capita financial data/watsuppval_percap.csv")[,8]
allfunddebtloanwatsuppsys.Nashville <- read.csv("per capita financial data/watsuppfundeddebt_percap.csv")[,8]
allfunddebtloansewsys.Nashville     <- read.csv("per capita financial data/sewsysfundeddebt_percap.csv")[,8]


watsupprecpts.Nashville          <- lm(log(Nashville.lt.short)~allwatsupplyrecpts.Nashville)
watsupplyexp.Nashville           <- lm(log(Nashville.lt.short)~allwatsupplyexp.Nashville)
sewsysexp.Nashville              <- lm(log(Nashville.lt.short)~allsewsysexp.Nashville)
watsupplyoutlays.Nashville       <- lm(log(Nashville.lt.short)~allwatsupplyoutlays.Nashville)
sewsysoutlays.Nashville          <- lm(log(Nashville.lt.short)~allsewsysoutlays.Nashville)
valwatsuppsys.Nashville          <- lm(log(Nashville.lt.short)~allvalwatsuppsys.Nashville)
funddebtloanwatsuppsys.Nashville <- lm(log(Nashville.lt.short)~allfunddebtloanwatsuppsys.Nashville)
funddebtloansewsys.Nashville     <- lm(log(Nashville.lt.short)~allfunddebtloansewsys.Nashville)

summary(watsupprecpts.Nashville)
summary(watsupplyexp.Nashville)
summary(sewsysexp.Nashville) #not signif
summary(watsupplyoutlays.Nashville) #not signif
summary(sewsysoutlays.Nashville) #not signif
summary(valwatsuppsys.Nashville) #marg
summary(funddebtloanwatsuppsys.Nashville)
summary(funddebtloansewsys.Nashville)

myFun <- function(lm) {
    out <- c(lm$coefficients[1],
             lm$coefficients[2],
             summary(lm)$coefficients[2,2],
             summary(lm)$coefficients[2, (3:4)],
             summary(lm)$r.squared)
    names(out) <- c("intercept","slope","slope.SE", "slope.tstat", "slope.pval","r.squared")
    return(out)}

linear.results.Nashville <- rbind(myFun(watsupprecpts.Nashville), myFun(watsupplyexp.Nashville), 
      myFun(sewsysexp.Nashville), myFun(watsupplyoutlays.Nashville), 
      myFun(sewsysoutlays.Nashville), myFun(valwatsuppsys.Nashville), 
      myFun(funddebtloanwatsuppsys.Nashville), myFun(funddebtloansewsys.Nashville))
rownames(linear.results.Nashville) <- c("watsupprecpts.Nashville", "watsupplyexp.Nashville", "sewsysexp.Nashville", 
                                  "watsupplyoutlays.Nashville", "sewsysoutlays.Nashville", "valwatsuppsys.Nashville",
                                  "funddebtloanwatsuppsys.Nashville", "funddebtloansewsys.Nashville")
write.csv(linear.results.Nashville, "linear regression results Nashville.csv")
