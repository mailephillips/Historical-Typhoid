
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

library(R.matlab)
library(quadprog)

typh.SanFrancisco <- read.csv("data/sanfranimputed13.csv")


Typhoid_monthly <- rep(0, 559)
for (i in 1:length(typh.SanFrancisco$Deaths)){
  for (j in 1:559){
    if (typh.SanFrancisco$Month_cum[i]==j) {Typhoid_monthly[j] <- Typhoid_monthly[j] + typh.SanFrancisco$Deaths[i]}
  }
}

Births_monthly <- rep(0, 559)
for (i in 1:length(typh.SanFrancisco$Births)){
  for (j in 1:559){
    if (typh.SanFrancisco$Month_cum[i]==j) {Births_monthly[j] <- Births_monthly[j] + typh.SanFrancisco$Births[i]}
  }
}

#import 4-week month population counts
monthlypops.SanFrancisco <- unlist((read.csv("monthly pops/monthlypop_SanFrancisco.csv"))[,2])

#function to calculate truncated Gaussian kernel weight matrix
getweightmatrix <- function(h, size) {
  W <- matrix(rep(0, size*size), ncol=size)
  for (i in 1:size) {
    for (j in 1:size) {
      if (abs(i-j) <= h) {W[i,j] <- exp((-0.5)*(((i-j)/h)^2))}
    }
  }
  
  #adjust weighs so sum of weights in each row is 1
  for (i in 1:size) {
    sumofRow <- sum(W[i,])
    W[i,]    <- W[i,]/sumofRow
  }
  return(W)
}

#function to fit cubic spline
getsplinefit <- function(kappa, nknots, m, penalty){
  x <- 0:m
  
  #set knots
  spacing <- length(x)/(nknots+1) #evenly spaced
  knots <- NULL
  for (i in 1:nknots){
    knots[i] <- floor(spacing*i)
  }
  
  #cubic spline basis
  Xfit <- matrix(NA, ncol=(length(knots)+4), nrow=length(x))
  Xfit[,1] <- rep(1, length(x))
  Xfit[,2] <- x
  Xfit[,3] <- x^2
  Xfit[,4] <- x^3
  
  loc <- 5
  for (i in 1:nknots){
    for (j in 1:length(x)){
      Xfit[j,loc] <- (max(x[j]-knots[i], 0))^3
    }
    loc <- loc + 1
  }
  
  XTX <- t(Xfit) %*% Xfit
  
  #A is the constraint matrix
  A <- matrix(NA, ncol=(length(knots)+4), nrow=(m + 1))
  for (i in 1:(m)){
    A[i,] <- Xfit[i+1,] - Xfit[i,]
  }
  
  A[(m+1),] <- (-1)*(Xfit[(m+1),])
  b            <- rep(0, (m +1))
  f            <- (-1)*t((t(Xfit)%*%kappa))
  
  H <- NULL
  if (penalty == -Inf) {H <- XTX
  } else {
    D <- matrix(rep(0, (nknots + 4)*(nknots + 4)) ,ncol=(nknots+4))
    for (i in 1:nknots){
      D[(i+4), (i+4)] <- 10^penalty
    }
    H <- XTX + D}
  
  temp1 <- solve.QP(Dmat = H,dvec = t(f),Amat = t(A),bvec = as.matrix(b))
  betahat <- (-1)*temp1$solution
  
  kappahat <- Xfit %*% betahat
  
  return(kappahat)
}

getinboundskappa <- function(Imatrix, kappahat, N) {
  max_Iter <- 5000
  inbounds <- 1
  counter  <- 1
  
  while (counter <= max_Iter) {
    nRecovered   <- Imatrix %*% kappahat
    Shat         <- N - nRecovered
    fractionSusc <- Shat/N
    
    if (min(fractionSusc) > 0) {
      break
    } else {
      kappahat <- .99* kappahat
      inbounds <- 0
      counter <- counter + 1 }
    
    if (counter > max_Iter) {break}
  }
  
  if (counter > max_Iter) {
    kappahat <- matrix(rep(0, length(kappahat), nrows=dim(kappahat)[1], ncol=dim(kappahat)[2]))
    inbounds = -1
  }
  
  return(list(kappahat, inbounds))
}

#Calculate wight matrix for CV
getweightmatrixcv <- function(h, size){
  #returns truncated Gaussian kernel weight matrix, with zeros in diagonal
  Wcv <-  matrix(rep(0, size*size), nrow=size, ncol=size)
  for (i in 1:size){
    for (j in 1:size){
      if ((abs(i-j) <= h) & (i != j)){
        Wcv[i,j] <- exp((-.5)*(((i-j)/h)^2))
      }
    }
  }
  
  for (i in 1:size){
    sumofRow <- sum(Wcv[i,])
    Wcv[i,] <- Wcv[i,]/sumofRow
  }
  
  return(Wcv)
}

#Cubic spline for CV
getsplinefitcv <- function(kappa, nknots, m, penalty) {
  x <- 0:m
  
  #set knots
  spacing <- length(x)/(nknots+1) #evenly spaced
  knots <- NULL
  for (i in 1:nknots){
    knots[i] <- floor(spacing*i)
  }
  
  #cubic spline basis
  Xfit <- matrix(NA, ncol=(length(knots)+4), nrow=length(x))
  Xfit[,1] <- rep(1, length(x))
  Xfit[,2] <- x
  Xfit[,3] <- x^2
  Xfit[,4] <- x^3
  
  loc <- 5
  for (i in 1:nknots){
    for (j in 1:length(x)){
      Xfit[j,loc] <- (max(x[j]-knots[i], 0))^3
    }
    loc <- loc + 1
  }
  
  kappahatCV <- matrix(NA, nrow=dim(kappa)[1], ncol=dim(kappa)[2])
  
  for (k in 1:length(x)) {
    Xfitcv <- Xfit[-k,]
    XTX <- t(Xfitcv) %*% Xfitcv
    
    A <- matrix(NA, ncol=dim(Xfit)[2], nrow=dim(Xfit)[1])
    for (i in 1:(m)){
      A[i,] <- Xfit[i+1,] - Xfit[i,]
    }
    
    A[(m+1),] <- (-1)*(Xfit[(m+1),])
    b            <- rep(0, (m +1))
    f            <- (-1)*t((t(Xfit)%*%kappa))
    
    D <- matrix(rep(0, (nknots + 4)*(nknots + 4)) ,ncol=(nknots+4))
    for (i in 1:nknots){
      D[(i+4), (i+4)] <- 10^penalty
    }
    H <- XTX + D
    
    temp2 <- solve.QP(Dmat = H,dvec = t(f),Amat = t(A),bvec = as.matrix(b))
    
    betahatcv <- (-1)*temp2$solution
    
    kappahat <- Xfit %*% betahatcv
    kappahatCV[k,1] <- kappahat[k,1]
  }
  
  return(kappahatCV)
}

#Calculate spline-smoothed fit
getSplineSmoother <- function(nknots, m, penalty){
  x <- 0:m
  
  #set knots
  spacing <- length(x)/(nknots+1) #evenly spaced
  knots <- NULL
  for (i in 1:nknots){
    knots[i] <- floor(spacing*i)
  }
  
  #cubic spline basis
  Xfit <- matrix(NA, ncol=(length(knots)+4), nrow=length(x))
  Xfit[,1] <- rep(1, length(x))
  Xfit[,2] <- x
  Xfit[,3] <- x^2
  Xfit[,4] <- x^3
  
  loc <- 5
  for (i in 1:nknots){
    for (j in 1:length(x)){
      Xfit[j,loc] <- (max(x[j]-knots[i], 0))^3
    }
    loc <- loc + 1
  }
  
  XTX <- t(Xfit) %*% Xfit
  
  
  D <- matrix(rep(0, (nknots + 4)*(nknots + 4)) ,ncol=(nknots+4))
  for (i in 1:nknots){
    D[(i+4), (i+4)] <- 10^penalty
  }
  
  S <- Xfit %*% solve(t(Xfit) %*%Xfit + D) %*% t(Xfit)
  return(S)
}

#Calculate logI(t) and logS(t)
getoldIS <- function(cases, births, delta, timePts) {
  cumbirths <- cumsum(births[1:130])
  cumreg <- lm(cumsum(cases[1:130]) ~ cumbirths)  
  ur <- coef(cumreg)[2]
  ur
  
  Ic.SanFrancisco <- cases/ur
  Ic.SanFrancisco
  
  predictedB <- (cbind(rep(1, length(births)),cumsum(births)))%*% as.matrix(coef(cumreg))
  D <-cumsum(cases) -predictedB
  
  lInew   <- log(as.vector(Ic.SanFrancisco)[2:timePts])
  Dold    <- as.vector(D)[1:(timePts-1)]
  
  # Smean   <-seq(0.125,1,0.1)*N.single 
  # CC      <- seq(.00001, .3, by = .0001)
  # llik <- matrix(ncol=length(CC), nrow= length(Smean))
  # for (i in 1:length(CC)){
  #   lIold   <- log((Ic.SanFrancisco[1:(timePts-1)]+1) + CC[i]*N.single)
  #   for (j in 1:length(Smean)) {
  #     lSold <- log(Smean[j] + Dold) 
  #     llik[j,i] <- logLik(glm(lInew ~ lIold + delta, family = "gaussian", offset = lSold))[1]
  #   }}
  # 
  # Smean_estim <- Smean[which(llik == max(llik), arr.ind = TRUE)[1]]
  # CC_estim    <- CC[which(llik == max(llik), arr.ind = TRUE)[2]]
  
  Smean_estim <- 52250
  CC_estim    <- 0.00011
  
  lIold <- log((Ic.SanFrancisco[1:(timePts-1)]+1) + CC_estim*N.single)
  lSold <- log(Smean_estim + Dold) 
  
  lISlist <- list(lIold, lSold)
  return(lISlist)
}

################################################################################
################################################################################
#####################################FIT MODEL##################################
################################################################################
################################################################################

City <- 'SanFrancisco'
N.single    <- 418000                #Median population count (used for MLE estimation)

timePts   <- length(Births_monthly)  #559 (4 week) months
m         <- 173                     #number of time points to allow for immunity decay function
startTime <- 1889                    #time 0
cases     <- Typhoid_monthly         #monthly death counts
n         <- 13                      #number of 4-week months per year
N         <- monthlypops.SanFrancisco#monthly population counts
S_med     <- 52250                   #median susceptible population count


fit_model <- function(nknots, h, penalty) {
  #generate dates of time series
  dates    <- NULL
  dates[1] <- startTime 
  for (i in 2:timePts) {
    dates[i] <- dates[i-1] + 1/n
  }
  
  #add 1 to cases to avoid problems with taking log(0)
  cases <- cases + 1
  
  #generate matrix for seasonal betas
  delta <- matrix(rep(0, (timePts)*n), nrow=timePts, ncol = n)
  for (j in 1:(timePts-1)){
    seas <- j %% n  # j mod n
    if (seas==0) {seas = n}
    delta[j, seas] <- 1
  }
  
  #take off last column to make number of cols be n-1, take off last row
  delta <- delta[,-dim(delta)[2]] 
  delta <- delta[-dim(delta)[1],]
  
  #generate vector log(I(t) + CC)
  oldIS <- getoldIS(cases[-(length(cases))], Births_monthly[-length(Births_monthly)], delta, timePts)
  logI <- oldIS[[1]]  #log(I(t) + CC)
  #logS <- oldIS[[2]]
  
  #generate vector log(I(t+1))
  Y <- matrix(rep(0, timePts), ncol=1)
  for (k in 1:(timePts)) {
    Y[k,1] <- log(cases[k+1])
  }
  
  ##########################################
  
  #generate matrix of previous cases
  Imatrix <- matrix(rep(0, (timePts)*(m +1)), ncol=(m +1))
  Imatrix[,1] <- cases
  
  prev=1
  for (l in 2:(m+1)) {
    for (p in 2:timePts){
      Imatrix[p,prev+1] <- Imatrix[p-1,prev]
    }
    prev <- prev + 1
  }
  
  #cut out last data point 
  dates <- dates[-timePts]
  Y <- Y[-timePts]
  Imatrix <- Imatrix[-timePts,]
  N <- N[-timePts]
  
  #reset length of timePts
  timePts <- timePts-1
  
  #generate long term beta smoother
  Wblt <- getweightmatrix(h, timePts)
  
  #generate identity matrix of same dimensions as long-term beta smoother
  Iblt <- diag(dim(Wblt)[2])
  
  ############We will now keep re-using the above matrices######
  
  #prep for first weighted least squares regression
  
  #get Z
  Z <- matrix(NA, nrow=dim(Imatrix)[1], ncol=dim(Imatrix)[2])
  for (i in 1: timePts){
    Z[i,] <- (-1/S_med)*Imatrix[i,]
  }
  
  #matrix of predictors
  X <- cbind(delta, logI, Z)
  
  #Offset
  lIoffsetN <- Y-(log(S_med)-1+(N/S_med))
  
  ################1st Weighted Least Squares Regression############
  theta        <- solve(t(X) %*% (Iblt-Wblt) %*% X) %*% t(X) %*% (Iblt-Wblt) %*% lIoffsetN
  logbeta.seas <- c(theta[(1:n-1),1], 0)
  alpha        <- theta[n,1]
  kappa        <- theta[(n+1):(n+m+1)]
  
  kappahat      <- getsplinefit(kappa, nknots, m, penalty)
  inboundskappa <- getinboundskappa(Imatrix, kappahat,N)
  kappahat      <- inboundskappa[[1]]
  inbounds      <- inboundskappa[[2]]
  
  ############################################################################
  ######Subsequent weight least squares regressions: backfitting algorithm####
  backfit <- 1
  
  while (inbounds != -1) {
    nRecovered <- Imatrix %*% kappahat
    Shat       <- N-nRecovered
    Sterm      <- log(Shat) 
    
    Z <- matrix(NA, nrow=dim(Imatrix)[1], ncol=dim(Imatrix)[2])
    for (i in 1:timePts) {
      Z[i,] <- ((-1)/Shat[i,1]) %*% Imatrix[i,]
    }
    
    lIoffsetS <- Y-Sterm
    
    X <- cbind(delta, logI, Z)
    theta <- solve(t(X) %*% (Iblt-Wblt) %*% X) %*% t(X) %*% (Iblt - Wblt) %*% lIoffsetS
    logbeta.seas <- c(theta[(1:(n-1)), 1], 0)
    alpha <- theta[n, 1]
    gamma <- 1 
    gamma_psi <- theta[((n+1):(m+n+1)), 1]
    
    kappa <- kappahat + gamma_psi
    kappahat      <- getsplinefit(kappa, nknots, m, penalty)
    
    if (backfit > 20) {break}
    backfit <- backfit + 1
    inboundskappa <- getinboundskappa(Imatrix, kappahat,N)
    kappahat      <- inboundskappa[[1]]
    inbounds      <- inboundskappa[[2]]
    
  }
  
  ######################Proceed with final fit########################
  nRecovered   <- Imatrix %*% kappahat
  Shat         <- N -nRecovered
  Sterm        <- Re(log(as.complex(Shat)))
  fractionSusc <- Shat/N
  
  if (min(fractionSusc) < 0) {
    inbounds = 0
  } else {inbounds = 1}
  
  if (max(kappahat) ==0) {
    inbounds <- -1
  }
  
  X         <- cbind(delta, logI, Sterm)
  betas     <- matrix(c(theta[(1:n),1], 1), ncol=1)
  f1hat     <- X %*% betas #parametric part
  beta.seas <- exp(logbeta.seas)
  f2hat     <- Wblt %*% (Y-f1hat) #local constant; non-parametric part
  beta.lt   <- exp(f2hat) 
  
  Yhat <-  f1hat + f2hat
  resids <-  Y-Yhat
  
  #R^2
  SSR  <- sum((Yhat-mean(Y))^2)
  SSTO <- sum((Y-mean(Y))^2)
  R2   <- SSR/SSTO
  
  #cross-validated weight matrix
  Wbltcv  <- getweightmatrixcv(h, timePts)
  f2hatcv <- Wbltcv %*% (Y-f1hat) 
  
  #cross-validated kappa fit
  kappahatCV     <- getsplinefitcv(kappa, nknots, m, penalty)
  nRecoveredCV   <- Imatrix %*% kappahatCV 
  ShatCV         <- N - nRecoveredCV
  StermCV        <- Re(log(as.complex(ShatCV)))
  fractionSuscCV <- ShatCV/N
  
  if (min(fractionSuscCV)<0) {
    inboundsCV <- 0
  } else {
    inboundsCV <- 1
  }
  
  if (max(kappahatCV) ==0) {
    inboundsCV <- -1
  }
  
  #put CV parts together
  Xcv     <- cbind(delta, logI, StermCV)
  betascv <- matrix(c(theta[(1:n),1], 1), ncol=1)
  f1hatcv <- Xcv %*% betascv
  Yhatcv  <- f1hatcv+f2hatcv
  cv      <- sum((Y-Yhatcv)^2) 
  
  thingtoreturn <- list(dates, alpha, gamma, kappahat, beta.seas, beta.lt, fractionSusc, Y, Yhat, R2, inbounds, cv, inboundsCV, nknots, m, n, penalty, h, Wblt, Iblt, X, Y, Yhat, kappa, logbeta.seas, f2hat)
  return(thingtoreturn)
  
}






###########################################################################
###########################################################################
#############################RUN ENTIRE MODEL##############################
###########################################################################
###########################################################################

runEntireModel <- function(minH, maxH, incrH, minPenalty, maxPenalty, incrPenalty, nknots){
  #attach(ds)
  round <- 1
  h     <- minH
  
  dimnum <- (((maxH-minH+1)/incrH))*(((maxPenalty-minPenalty+1)/incrPenalty))
  
  resultsList      <- matrix(NA, ncol=4, nrow=dimnum)
  expList          <- matrix(NA, ncol=2, nrow=dimnum)
  kappaList        <- matrix(NA, ncol=dimnum, nrow=(m+1))
  beta.seasList    <- matrix(NA, ncol=dimnum, nrow=n)
  beta.ltList      <- matrix(NA, ncol=dimnum, nrow=(timePts-1))
  fractionSuscList <- matrix(NA, ncol=dimnum, nrow=(timePts-1))
  YhatList         <- matrix(NA, ncol=dimnum, nrow=(timePts-1))
  r2List           <- rep(NA, dimnum)
  cvList           <- rep(NA, dimnum)
  
  listoflists <- NULL
  
  while (h <= maxH) {
    penalty <-  minPenalty
    while (penalty <= maxPenalty) {
      running_values <- c(h, penalty)
      mod1         <- fit_model(nknots, h, penalty)
      dates        <- mod1[[1]]
      alpha        <- mod1[[2]]
      gamma        <- mod1[[3]]
      kappa        <- mod1[[4]]
      beta.seas    <- mod1[[5]]
      beta.lt      <- mod1[[6]]
      fractionSusc <- mod1[[7]]
      Y            <- mod1[[8]]
      Yhat         <- mod1[[9]]
      R2           <- mod1[[10]]
      inbounds     <- mod1[[11]]
      cv           <- mod1[[12]]
      inboundsCV   <- mod1[[13]]
      
      resultsList[round,1]     <- h
      resultsList[round,2]     <- penalty
      resultsList[round,3]     <- inbounds
      resultsList[round,4]     <- inboundsCV
      expList[round,1]         <- alpha
      expList[round,2]         <- gamma
      kappaList[,round]        <- kappa
      beta.seasList[,round]    <- beta.seas
      beta.ltList[,round]      <- beta.lt
      fractionSuscList[,round] <- fractionSusc
      YhatList[,round]         <- Yhat
      r2List[round]            <- R2
      cvList[round]            <- cv
      
      round   <- round + 1
      penalty <- penalty + incrPenalty
      print(running_values)
    }
    h = h + incrH
  }
  
  rtrnlist <- list(resultsList, expList, kappaList, beta.seasList, beta.ltList, fractionSuscList, YhatList, r2List, cvList) 
  return(rtrnlist)
}



###########################################################################
###########################################################################
#############################RUN ENTIRE MODEL##############################
###########################################################################
###########################################################################

runEntireModel <- function(minH, maxH, incrH, minPenalty, maxPenalty, incrPenalty, nknots){
  #attach(ds)
  round <- 1
  h     <- minH
  
  dimnum <- (((maxH-minH+1)/incrH))*(((maxPenalty-minPenalty+1)/incrPenalty))
  
  resultsList      <- matrix(NA, ncol=4, nrow=dimnum)
  expList          <- matrix(NA, ncol=2, nrow=dimnum)
  kappaList        <- matrix(NA, ncol=dimnum, nrow=(m+1))
  beta.seasList    <- matrix(NA, ncol=dimnum, nrow=n)
  beta.ltList      <- matrix(NA, ncol=dimnum, nrow=(timePts-1))
  fractionSuscList <- matrix(NA, ncol=dimnum, nrow=(timePts-1))
  YhatList         <- matrix(NA, ncol=dimnum, nrow=(timePts-1))
  r2List           <- rep(NA, dimnum)
  cvList           <- rep(NA, dimnum)
  
  listoflists <- NULL
  
  while (h <= maxH) {
    penalty <-  minPenalty
    while (penalty <= maxPenalty) {
      running_values <- c(h, penalty)
      mod1         <- fit_model(nknots, h, penalty)
      dates        <- mod1[[1]]
      alpha        <- mod1[[2]]
      gamma        <- mod1[[3]]
      kappa        <- mod1[[4]]
      beta.seas    <- mod1[[5]]
      beta.lt      <- mod1[[6]]
      fractionSusc <- mod1[[7]]
      Y            <- mod1[[8]]
      Yhat         <- mod1[[9]]
      R2           <- mod1[[10]]
      inbounds     <- mod1[[11]]
      cv           <- mod1[[12]]
      inboundsCV   <- mod1[[13]]
      
      resultsList[round,1]     <- h
      resultsList[round,2]     <- penalty
      resultsList[round,3]     <- inbounds
      resultsList[round,4]     <- inboundsCV
      expList[round,1]         <- alpha
      expList[round,2]         <- gamma
      kappaList[,round]        <- kappa
      beta.seasList[,round]    <- beta.seas
      beta.ltList[,round]      <- beta.lt
      fractionSuscList[,round] <- fractionSusc
      YhatList[,round]         <- Yhat
      r2List[round]            <- R2
      cvList[round]            <- cv
      
      #savelist    <- list(resultsList, expList, kappaList, beta.seasList, beta.ltList, fractionSuscList, YhatList, r2List, cvList) 
      #listoflists <- c(listoflists, savelist) 
      
      round   <- round + 1
      penalty <- penalty + incrPenalty
      print(running_values)
      }
    h = h + incrH
  }
  
  rtrnlist <- list(resultsList, expList, kappaList, beta.seasList, beta.ltList, fractionSuscList, YhatList, r2List, cvList) 
  #detach(ds)
  return(rtrnlist)
}



##############################RUN FUNCTIONS AND TEST###########################

#range of smoothing bandwidth (h) and incremental step size
minH=2 
maxH=30
incrH=1
#range of spline penalty weights (weights are 10^penalty) and incremental step size
minPenalty=-2 
maxPenalty=30
incrPenalty=1
#number of spline fit knots of immunity kernel
nknots=10

result <- runEntireModel(minH, maxH, incrH, minPenalty, maxPenalty, incrPenalty, nknots)
resultsList      <- result[[1]] 
expList          <- result[[2]]
kappaList        <- result[[3]]  
beta.seasList    <- result[[4]]
beta.ltList      <- result[[5]]
fractionSuscList <- result[[6]] 
YhatList         <- result[[7]]
r2List           <- result[[8]]
cvList           <- result[[9]]

cvListTemp <- cvList 
for (i in 1:length(cvList)) {
  if (resultsList[i,3]==0) {cvListTemp[i] <- Inf}
}

sortedcvlist       <- sort(cvListTemp)
cvlistorder        <- order(cvListTemp)
optComboList       <- matrix(NA, nrow=length(cvListTemp), ncol=6)
optComboList[,1]   <- cvlistorder
optComboList[,2:5] <- resultsList[cvlistorder,]
optComboList[,6]   <- sortedcvlist

hOpt.SF       <- optComboList[1,2] #15
penaltyOpt.SF <- optComboList[1,3] #-2

finmod       <- fit_model(nknots, hOpt.SF, penaltyOpt.SF)
dates        <- finmod[[1]]
alpha        <- finmod[[2]]
gamma        <- finmod[[3]]
kappa        <- finmod[[4]]
beta.seas    <- finmod[[5]]
beta.lt      <- finmod[[6]]
fractionSusc <- finmod[[7]]
Y            <- finmod[[8]]
Yhat         <- finmod[[9]]
R2           <- finmod[[10]]
inbounds     <- finmod[[11]]
cv           <- finmod[[12]]
inboundsCV   <- finmod[[13]]


plot.new()
par(mfrow=c(2,2))
plot(Y, Yhat, col="blue", main="Y vs Yhat")
abline(a = 0, b = 1)
plot(1:n, beta.seas, col="blue", type="l", main="Seasonal Beta Transmission Rate")
plot(dates, log(beta.lt), col="blue", type="l", main="Log Long Term Transmission Rate")
plot(dates, beta.lt, col="blue", type="l", main="Long Term Transmission Rate")
dev.copy(png,'Model Parameter Plots San Francisco.png')
dev.off()

plot.new()
par(mfrow=c(1,1))
plot(dates, beta.lt, col="blue", type="l", main="Long Term Transmission Rate")
dev.copy(png,'B.lt San Francisco.png')
dev.off()


mod.params   <- as.data.frame(cbind(alpha, gamma, R2))
beta.seas.ds <- as.data.frame(beta.seas)
beta.lt.ds   <- as.data.frame(beta.lt)
Y.ds         <- as.data.frame(cbind(Y, Yhat))

write.csv(mod.params, file = "San Francisco mod params.csv")
write.csv(beta.seas.ds, file = "San Francisco B_seas.csv")
write.csv(beta.lt.ds, file = "San Francisco Beta_lt.csv")
write.csv(Y.ds, file = "San Francisco Y.csv")
