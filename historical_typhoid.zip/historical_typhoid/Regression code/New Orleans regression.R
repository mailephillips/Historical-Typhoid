
rm(list=ls(all=TRUE))

setwd("~/Desktop/historical_typhoid")

b.ltALL <- read.csv("final B_lts.csv")[,-1]

b.lt.yr <- b.ltALL[,8]
yrbeta.lt <- rep(NA, 43)
for (i in 1:43){
  yrbeta.lt[i] <- mean(b.lt.yr[(1+(13*(i-1))):(13+(13*(i-1)))], na.rm=T)
}
B.lt.short <- yrbeta.lt[14:length(yrbeta.lt)]

fin.vars        <- read.csv("per capita financial data/percap_financial_New_Orleans.csv")[,-1]
mod.sum <- function(lm) {
  out <- c(exp(lm$coefficients[1]),
           exp(lm$coefficients[2]),
           summary(lm)$coefficients[2,4],
           summary(lm)$r.squared)
  names(out) <- c("intercept","slope","slope.pval","r.squared")
  return(out)}

sumlist <- matrix(NA, nrow=10, ncol=4)
for (v in 1:10) {
  sumlist[v,] <- round(mod.sum(lm(log(B.lt.short)~fin.vars[,v])),2)
}

rownames(sumlist) <- c("WSrecpts",
                       "WSexp",
                       "SSexp",
                       "WSoutlays",
                       "SSoutlays",
                       "WSsys",
                       "WSdebtloan",
                       "SSdebtloan",
                       "WSoverallinv",
                       "SSoverallinv")
colnames(sumlist) <- c("intercept","slope","slope.pval","r.squared")

write.csv(sumlist, "linear regression results New Orleans.csv")

